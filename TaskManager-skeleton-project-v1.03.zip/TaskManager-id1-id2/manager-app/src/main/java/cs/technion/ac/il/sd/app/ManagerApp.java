package cs.technion.ac.il.sd.app;

import java.io.File;

public interface ManagerApp {
  void processFile(File file);
}
