package makefileVertex;

/**
 * Created by akravi on 5/11/2016.
 */

public enum FileOrAssignment {Unknown, File, Assignment}
