package cs.technion.ac.il.sd.app;

import java.io.File;

public interface Makefile {
  void processFile(File file);
}
