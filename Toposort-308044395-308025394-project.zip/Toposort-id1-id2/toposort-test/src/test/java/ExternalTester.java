import cs.technion.ac.il.sd.External;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

public class ExternalTester implements External {
  public final List<Integer> list = new LinkedList<>();
  public boolean hasFailed = false;

  @Override
  public void process(int i) {
    list.add(i);
  }

  @Override
  public void fail() {
    hasFailed = true;
  }
}
