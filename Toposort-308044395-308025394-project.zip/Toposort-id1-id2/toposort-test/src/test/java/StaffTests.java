import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import cs.technion.ac.il.sd.External;
import cs.technion.ac.il.sd.app.Toposort;
import cs.technion.ac.il.sd.app.ToposortModule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.io.File;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

public class StaffTests {
  private final ExternalTester tester = new ExternalTester();
  private final Injector injector = Guice.createInjector(new ToposortModule(), new AbstractModule() {
    @Override
    protected void configure() {
      // will be replaced with a real implementation in staff tests
      bind(External.class).toInstance(tester);
    }
  });
  private final Toposort $ = injector.getInstance(Toposort.class);

  private void processFile(String name) {
    $.processFile(new File(getClass().getResource(name + "_graph.txt").getFile().replaceAll("%20", " ")));
  }

  private List<Integer> parseSolution(String name) {
    Scanner scanner = new Scanner(getClass().getResourceAsStream(name + "_solution.txt")).useDelimiter("[\\s,]");
    LinkedList<Integer> list = new LinkedList<>();
    while (scanner.hasNext())
      list.add(scanner.nextInt());
    return list;
  }

  @Rule
  public Timeout globalTimeout = Timeout.seconds(12);

  private void verifyList(List<Integer> actual) {
    verifyList(actual, tester.list);
  }

  private void verifyList(List<Integer> actual, List<Integer> expected) {
    assertEquals("order or conent of topoligical sort differed", expected, actual);
    assertFalse("fail() shouldn't have been called but was", tester.hasFailed);
  }

  private void verifyFailed() {
    assertTrue("fail() should have been called but wasn't", tester.hasFailed);
  }

  @Test
  public void testSimple() {
    processFile("small");
    verifyList(Arrays.asList(1, 2));
  }

  @Test
  public void testFail() throws Exception {
    processFile("cycle");
    verifyFailed();
  }

  @Test
  public void largeTest() throws Exception {
    processFile("large");
    LinkedList<Integer> list = new LinkedList<>();
    for (int i = 1; i <= 1000; i++) {
      list.add(i);
    }
    verifyList(list);
  }

  @Test
  public void largeLinearTest() throws Exception {
    String name = "large_linear";
    processFile(name);
    verifyList(parseSolution(name));
  }

  @Test
  public void phasesTest() throws Exception {
    String name = "phases";
    processFile(name);
    Iterator<Integer> solutionIterator = parseSolution(name).iterator();
    Iterator<Integer> actualIterator = tester.list.iterator();
    while (solutionIterator.hasNext()) {
      Set<Integer> expected = new HashSet<>();
      Set<Integer> actual = new HashSet<>();
      for (int i = 0; i < 10; i++) {
        expected.add(solutionIterator.next());
        actual.add(actualIterator.next());
      }
      assertEquals("Phase vertices should match solution in content", expected, actual);
    }
  }

  @Test
  public void islandsTest() throws Exception {
    String name = "islands";
    processFile(name);
    Iterator<Integer> solutionIterator = parseSolution(name).iterator();
    Iterator<Integer> actualIterator = tester.list.iterator();
    HashSet<Integer> islands = new HashSet<>();
    while (actualIterator.hasNext()) {
      Integer next = actualIterator.next();
      if (next % 10 == 0)
        islands.add(next);
      else
        assertEquals(solutionIterator.next(), next);
    }
    assertEquals("multiples of 10 should be island vertices",
        IntStream.rangeClosed(1, 100).mapToObj(x -> x * 10).collect(Collectors.toSet()), islands);
  }

  private static <T> List<T> filter(List<T> list, Predicate<T> predicate) {
    return list.stream().filter(predicate).collect(Collectors.toList());
  }

  @Test
  public void testSeparate() throws Exception {
    String name = "separate";
    processFile(name);
    Predicate<Integer> isEven = x -> x % 2 == 0;
    Predicate<Integer> isOdd = x -> !isEven.test(x);
    List<Integer> solution = parseSolution(name);
    List<Integer> actual = tester.list;
    verifyList(filter(solution, isEven), filter(actual, isEven));
    verifyList(filter(solution, isOdd), filter(actual, isOdd));
  }

  @Test
  public void testLargeCycle() throws Exception {
    processFile("large_cycle");
    verifyFailed();
  }

  @Test
  public void testSmallCycle() throws Exception {
    processFile("small_cycle");
    verifyFailed();
  }
}
