package toposortImpl;

import graph.Graph;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by rina.berlin on 4/14/2016.
 */
public class ToposortImplTest {
    //@Test
    //Graph mockedGraph = mock(Grpah.class);

}